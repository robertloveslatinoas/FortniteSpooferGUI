using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace FortniteSpooferGUI
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            Button btnSpoof = new Button { Text = "Spoof HWID", Left = 10, Top = 10, Width = 200 };
            btnSpoof.Click += btnSpoof_Click;
            Controls.Add(btnSpoof);

            Button btnClean = new Button { Text = "Clean Fortnite Logs", Left = 10, Top = 50, Width = 200 };
            btnClean.Click += btnClean_Click;
            Controls.Add(btnClean);

            Button btnExit = new Button { Text = "Exit", Left = 10, Top = 90, Width = 200 };
            btnExit.Click += btnExit_Click;
            Controls.Add(btnExit);
        }

        private void btnSpoof_Click(object sender, EventArgs e)
        {
            Process.Start("powershell.exe", "-ExecutionPolicy Bypass -File spoof.ps1");
        }

        private void btnClean_Click(object sender, EventArgs e)
        {
            Process.Start("cleaner.bat");
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

Start-Process -FilePath "volumeid.exe" -ArgumentList "C: 4D2A-9C11" -Wait

Get-NetAdapter | ForEach-Object {
    $mac = -join ((65..70)+(48..57) | Get-Random -Count 6 | % {[char]$_})
    Set-NetAdapterAdvancedProperty -Name $_.Name -RegistryKeyword "NetworkAddress" -RegistryValue $mac
}

New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Cryptography" -Name "MachineGuid" -Value ([guid]::NewGuid()).Guid -Force
